package logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * 회원 관련 이벤트 로깅 전용 (DB 접근 없음 / DTC 건드리지 않음)
 */
@Component
public class MemberEventLogger {
    private static final Logger log = LoggerFactory.getLogger(MemberEventLogger.class);

    public void signup(String memberId) {
        log.info("SIGNUP memberId={}", memberId);
    }

    public void login(String memberId) {
        log.info("LOGIN memberId={}", memberId);
    }

    public void logout(String memberId) {
        log.info("LOGOUT memberId={}", memberId);
    }

    public void upgradeRequest(String memberId, String targetTier) {
        log.info("UPGRADE_REQUEST memberId={} targetTier={}", memberId, targetTier);
    }

    public void upgradeApproved(String memberId, String targetTier) {
        log.info("UPGRADE_APPROVED memberId={} targetTier={}", memberId, targetTier);
    }
}
