package main.DTC;

import java.util.*;
import java.util.regex.*;

public class TermsParser {

    // 패턴들
    private static final Pattern P_SUPP = Pattern.compile("(^|\\R)\\s*부\\s*칙\\s*(?:\\R|$)");
    private static final Pattern P_ART  = Pattern.compile("제\\s*(\\d{1,2})\\s*조\\s*\\(([^)]*)\\)", Pattern.MULTILINE);

    // 번호 섹션: 1. 제목 / 1) 제목 / 1 ) 제목  등
    private static final Pattern P_NUMSEC = Pattern.compile(
        "^(\\d{1,2})\\s*[\\.)]\\s*(.+)$", Pattern.MULTILINE);

    private static boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }

    public static List<TermsSection> parseByArticle(String raw) {
        List<TermsSection> out = new ArrayList<>();
        if (isBlank(raw)) return out;

        // 0) 부칙 분리
        String main = raw;
        String supp = null;
        Matcher ms = P_SUPP.matcher(raw);
        if (ms.find()) {
            int idx = ms.start();
            main = raw.substring(0, idx).trim();
            supp = raw.substring(idx).trim(); // "부칙" 포함 전체
        }

        // 1) "제n조 (제목)" 존재하면 그 방식으로 파싱
        if (P_ART.matcher(main).find()) {
            out.addAll(parseArticleStyle(main));
        } else {
            // 2) 없으면 번호 섹션 방식으로 파싱
            out.addAll(parseNumberedSections(main));
        }

        // 3) 부칙 붙이기
        if (!isBlank(supp)) {
            out.add(new TermsSection("부칙", "", supp));
        }
        return out;
    }

    // --- A. 약관형: 제n조 (제목) ---
    private static List<TermsSection> parseArticleStyle(String s) {
        List<TermsSection> list = new ArrayList<>();
        Matcher m = P_ART.matcher(s);
        List<int[]> spans = new ArrayList<>();
        while (m.find()) spans.add(new int[]{m.start(), m.end()});
        for (int i = 0; i < spans.size(); i++) {
            int[] cur = spans.get(i);
            int start = cur[0], endHdr = cur[1];
            int end = (i + 1 < spans.size()) ? spans.get(i + 1)[0] : s.length();
            Matcher mh = P_ART.matcher(s.substring(start, end));
            if (mh.find()) {
                String no = mh.group(1).trim();
                String title = mh.group(2).trim();
                String body = s.substring(endHdr, end).trim();
                list.add(new TermsSection("제" + no + "조", title, body));
            }
        }
        // 머리말(전문) 처리: 첫 조 이전 텍스트가 있으면 보존
        Matcher first = P_ART.matcher(s);
        if (first.find()) {
            int pre = first.start();
            String preface = s.substring(0, pre).trim();
            if (!isBlank(preface)) list.add(0, new TermsSection("전문", "", preface));
        }
        return list;
    }

    // --- B. 번호형: 1. 제목 / 2) 제목 ---
    private static List<TermsSection> parseNumberedSections(String s) {
        List<TermsSection> list = new ArrayList<>();
        Matcher m = P_NUMSEC.matcher(s);

        // 번호줄 시작 위치/헤더 끝 위치 수집
        List<int[]> spans = new ArrayList<>();
        while (m.find()) spans.add(new int[]{m.start(), m.end()}); // [헤더시작, 헤더끝]

        if (spans.isEmpty()) {
            // 번호 섹션도 없으면 전체를 전문으로 반환
            if (!isBlank(s)) list.add(new TermsSection("전문", "", s.trim()));
            return list;
        }

        // 머리말(전문): 첫 번호 전 텍스트
        int firstStart = spans.get(0)[0];
        String preface = s.substring(0, firstStart).trim();
        if (!isBlank(preface)) list.add(new TermsSection("전문", "", preface));

        // 각 번호 섹션 만들기
        for (int i = 0; i < spans.size(); i++) {
            int headStart = spans.get(i)[0];
            int headEnd   = spans.get(i)[1];
            int end       = (i + 1 < spans.size()) ? spans.get(i + 1)[0] : s.length();

            // 헤더에서 번호와 제목 추출
            Matcher h = P_NUMSEC.matcher(s.substring(headStart, end));
            String no = null, title = null;
            if (h.find()) {
                no = h.group(1).trim();
                title = h.group(2).trim();
            }
            String body = s.substring(headEnd, end).trim();

            // 제목이 비면 "항목 n"으로 대체
            String key = (no != null) ? "항목 " + no : "항목";
            String ttl = (title != null && !title.isEmpty()) ? title : "";

            list.add(new TermsSection(key, ttl, body));
        }
        return list;
    }
}
