package main.DTC;

import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.List;

@Service
public class TermsService {
    private final DTC_DB dtc;

    public TermsService(DTC_DB dtc) {
        this.dtc = dtc;
    }

    public List<TermsSection> getSectionsByCode(String code) {
        String raw = dtc.findContentByCode(code);
        if (raw == null || raw.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return TermsParser.parseByArticle(raw);
    }
}
