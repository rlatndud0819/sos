package main.DTC;

import java.sql.*;
import org.springframework.stereotype.Component;

@Component
public class DTC_DB {
    private Connection getConnection() throws Exception {
        Class.forName("com.filemaker.jdbc.Driver");
        return DriverManager.getConnection(
            "jdbc:filemaker://xcd006.cafe24.com:2399/KSY_MypageDB",
            "admin", "2211"
        );
    }

    public String findContentByCode(String code) {
        // 방어: null/빈값 차단 + trim
        if (code == null) return null;
        final String norm = code.trim();

        // 1) 문자열 동일 비교 먼저
        final String sqlText = "SELECT content FROM DTC WHERE code = ?";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sqlText)) {
            ps.setString(1, norm);
            ps.setMaxRows(1);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String val = rs.getString("content");
                    System.out.println("[DTC_DB] hit TEXT = match for code=" + norm);
                    return val;
                }
            }
        } catch (Exception e) {
            System.err.println("[DTC_DB] TEXT match error: " + e);
        }

        // 2) 숫자 캐스팅 비교 (code 컬럼이 텍스트라도 숫자처럼 저장된 경우 커버)
        if (norm.matches("^\\d+$")) {
            final String sqlNum = "SELECT content FROM DTC WHERE CAST(code AS INTEGER) = ?";
            try (Connection c = getConnection();
                 PreparedStatement ps = c.prepareStatement(sqlNum)) {
                ps.setInt(1, Integer.parseInt(norm));
                ps.setMaxRows(1);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String val = rs.getString("content");
                        System.out.println("[DTC_DB] hit NUM = match for code=" + norm);
                        return val;
                    }
                }
            } catch (Exception e) {
                System.err.println("[DTC_DB] NUM match error: " + e);
            }
        }

        // 3) 마지막으로 zero-pad 저장을 대비 (예: "02","003")
        if (norm.matches("^\\d+$")) {
            String p2 = String.format("%02d", Integer.parseInt(norm));
            String p3 = String.format("%03d", Integer.parseInt(norm));
            final String sqlPad = "SELECT content FROM DTC WHERE code IN (?, ?)";
            try (Connection c = getConnection();
                 PreparedStatement ps = c.prepareStatement(sqlPad)) {
                ps.setString(1, p2);
                ps.setString(2, p3);
                ps.setMaxRows(1);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        String val = rs.getString("content");
                        System.out.println("[DTC_DB] hit PAD = match for code=" + norm + " via " + p2 + "/" + p3);
                        return val;
                    }
                }
            } catch (Exception e) {
                System.err.println("[DTC_DB] PAD match error: " + e);
            }
        }

        System.err.println("[DTC_DB] no row for code=" + norm);
        return null;
    }
}
