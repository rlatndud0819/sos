package main.DTC;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class DTC_Controller {

    private final DTC_DB dtc;
    public DTC_Controller(DTC_DB dtc){ this.dtc = dtc; }

    @GetMapping(value = "/api/terms/content.do", produces = "text/plain; charset=UTF-8")
    public String getContent(@RequestParam String code) {
        String content = dtc.findContentByCode(code);
        return (content != null && !content.isEmpty()) ? content : "내용이 없습니다.";
    }


    @Controller
    public class TermsController {
        private final TermsService service;

        public TermsController(TermsService service) {
            this.service = service;
        }

        // JSON API: 조 단위 결과 조회
        @GetMapping(value="/api/terms/sections.do", produces="application/json; charset=UTF-8")
        @ResponseBody
        public List<TermsSection> getSections(@RequestParam String code) {
            return service.getSectionsByCode(code);
        }

        // JSP 렌더: 아코디언으로 보기
        @GetMapping("/member/User_Agreement.do")
        public String showTerms(@RequestParam String code, Model model) {
            model.addAttribute("sections", service.getSectionsByCode(code));
            return "/jsp/member/User_Agreement";
        }
    }

}
