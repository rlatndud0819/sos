package main.DTC;

public class TermsSection {
    private String key;    // "제1조"
    private String title;  // "목적"
    private String body;   // 해당 조 본문(원문 줄바꿈 유지)

    public TermsSection() {}
    public TermsSection(String key, String title, String body) {
        this.key = key; this.title = title; this.body = body;
    }
    public String getKey() { return key; }
    public String getTitle() { return title; }
    public String getBody() { return body; }
    public void setKey(String v) { this.key = v; }
    public void setTitle(String v) { this.title = v; }
    public void setBody(String v) { this.body = v; }
}
