package main.web;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.UUID;
import org.springframework.web.multipart.MultipartFile;

public class UploadUtil {

    // 로컬과 서버의 실제 저장 디렉터리
    // 로컬 예: ~/eclipse-tomcat9-work/uploads/img
    // 서버 예: /var/www/app-uploads/img
    private static final String LOCAL_DIR  = System.getProperty("user.home") + "/eclipse-tomcat9-work/uploads/img";
    private static final String SERVER_DIR = "/var/www/app-uploads/img";

    // 정적 리소스 매핑된 공개 URL prefix
    // 예: http://localhost:8080/dpgb/img/ 또는 https://site.example.com/img/
    // 컨텍스트에 맞게 교체
    private static final String LOCAL_URL_PREFIX  = "/img/";
    private static final String SERVER_URL_PREFIX = "/img/";

    public static class Saved {
        public final String fileSystemPath;
        public final String publicUrl;
        public Saved(String p, String u){ this.fileSystemPath = p; this.publicUrl = u; }
    }

    public static Saved saveAndReturnUrl(MultipartFile file, String preferredName) throws IOException {
        if (file == null || file.isEmpty()) return null;

        String mode = System.getenv("UPLOAD_MODE");
        boolean isLocal = "local".equalsIgnoreCase(mode);

        String baseDir = isLocal ? LOCAL_DIR : SERVER_DIR;
        File dir = new File(baseDir);
        if (!dir.exists() && !dir.mkdirs()){
            throw new IOException("Cannot create upload dir: " + baseDir);
        }

        String ext = getExt(file.getOriginalFilename());
        String safeName = (preferredName != null && !preferredName.trim().isEmpty())
                ? preferredName.trim() : UUID.randomUUID().toString();
        String filename = safeName + (ext.isEmpty() ? "" : "." + ext);

        File dest = new File(dir, filename);
        try (FileOutputStream out = new FileOutputStream(dest)) {
            out.write(file.getBytes());
        }

        String urlPrefix = isLocal ? LOCAL_URL_PREFIX : SERVER_URL_PREFIX;
        String publicUrl = urlPrefix + filename;

        return new Saved(dest.getAbsolutePath(), publicUrl);
    }

    private static String getExt(String name){
        if (name == null) return "";
        int idx = name.lastIndexOf('.');
        return (idx >= 0 && idx < name.length()-1) ? name.substring(idx+1) : "";
    }
}