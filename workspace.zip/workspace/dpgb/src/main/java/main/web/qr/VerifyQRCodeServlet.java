package main.web.qr;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/qrAuth")
public class VerifyQRCodeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        System.out.println("QR 스캔으로 인증 요청 수신");
        
        HttpSession session = request.getSession(false);
        String contextPath = request.getContextPath();
        
        if (session != null && session.getAttribute("userEmail") != null) {
            String userEmail = (String) session.getAttribute("userEmail");
            System.out.println("QR 인증 성공: " + userEmail);
            
            // ✅ .do 확장자 추가
            response.sendRedirect(contextPath + "/qrAuthSuccess.do");
            
        } else {
            System.out.println("QR 인증 실패: 로그인 필요");
            response.sendRedirect(contextPath + "/login.do?message=qr_login_required");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}
