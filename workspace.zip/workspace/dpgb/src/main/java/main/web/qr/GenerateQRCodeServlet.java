package main.web.qr;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

// @WebServlet("/generateQRCode") // 어노테이션 제거
public class GenerateQRCodeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // ✅ userEmail로 세션 확인 (memberController와 일치)
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userEmail") == null) {
            response.setContentType("text/plain; charset=UTF-8");
            response.getWriter().write("로그인이 필요합니다.");
            return;
        }
        
        try {
            // QR 코드가 가리킬 URL 생성
            String scheme = request.getScheme();
            String serverName = request.getServerName();
            int serverPort = request.getServerPort();
            String contextPath = request.getContextPath();
            
            StringBuilder qrUrl = new StringBuilder();
            qrUrl.append(scheme).append("://").append(serverName);
            
            if ((scheme.equals("http") && serverPort != 80) || 
                (scheme.equals("https") && serverPort != 443)) {
                qrUrl.append(":").append(serverPort);
            }
            
            qrUrl.append(contextPath).append("/qrAuth");
            
            System.out.println("QR 생성 URL: " + qrUrl.toString());
            
            // QR 코드 생성 (200x200)
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(
                qrUrl.toString(), 
                BarcodeFormat.QR_CODE, 
                200, 
                200
            );
            
            BufferedImage qrImage = MatrixToImageWriter.toBufferedImage(bitMatrix);
            
            // 응답 설정
            response.setContentType("image/png");
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            response.setHeader("Pragma", "no-cache");
            response.setDateHeader("Expires", 0);
            
            // 이미지 출력
            OutputStream outputStream = response.getOutputStream();
            ImageIO.write(qrImage, "PNG", outputStream);
            outputStream.flush();
            outputStream.close();
            
        } catch (WriterException e) {
            System.err.println("QR 코드 생성 실패: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.setContentType("text/plain; charset=UTF-8");
            response.getWriter().write("QR 코드 생성에 실패했습니다.");
        }
    }
}
