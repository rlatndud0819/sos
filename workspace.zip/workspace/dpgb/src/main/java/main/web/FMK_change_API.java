package main.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FMK_change_API {

    @Autowired
    private MemberDAO memberDAO;

    // GET /api/member - 세션의 userEmail 기준으로 member JSON 반환
    @GetMapping("/api/member")
    public Map<String, Object> getMember(HttpServletRequest request) {
        Map<String, Object> resp = new HashMap<>();
        HttpSession s = request.getSession(false);
        if (s == null || s.getAttribute("userEmail") == null) {
            resp.put("ok", false);
            resp.put("error", "login_required");
            return resp;
        }

        String email = (String) s.getAttribute("userEmail");
        try {
            MemberVO vo = memberDAO.findByEmail(email);
            if (vo == null) {
                resp.put("ok", false);
                resp.put("error", "member_not_found");
                return resp;
            }
            resp.put("ok", true);
            resp.put("member", vo);
            return resp;
        } catch (Exception e) {
            e.printStackTrace();
            resp.put("ok", false);
            resp.put("error", "db_error");
            resp.put("message", e.getMessage());
            return resp;
        }
    }
}