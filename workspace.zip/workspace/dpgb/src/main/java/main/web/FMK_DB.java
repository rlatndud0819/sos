package main.web;

import java.sql.*;
import java.util.HashSet;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Component;

/**
 * FileMaker 기반 회원 DB 접근 컴포넌트
 * - 이메일 중복 체크
 * - 회원가입
 * - 로그인 인증
 * - 회원정보 조회
 * - 정회원 신청 및 이미지 URL 저장
 * - 정회원 승인 상태 확인
 */
@Component("fmkDatabase")
public class FMK_DB {

    /** FileMaker JDBC 커넥션 획득 */
    private Connection getConnection() throws SQLException {
        try {
            Class.forName("com.filemaker.jdbc.Driver");
            return DriverManager.getConnection(
                "jdbc:filemaker://xcd006.cafe24.com:2399/KSY_MypageDB",
                "admin",
                "2211"
            );
        } catch (ClassNotFoundException e) {
            throw new SQLException("FileMaker JDBC 드라이버를 찾을 수 없습니다: " + e.getMessage());
        }
    }

    /** ResultSet에 특정 컬럼 존재 여부 */
    private boolean hasColumn(ResultSet rs, String colName) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        for (int i = 1; i <= md.getColumnCount(); i++) {
            if (colName.equalsIgnoreCase(md.getColumnName(i))) return true;
        }
        return false;
    }

    /** 지정 테이블의 컬럼 목록 조회 */
    private Set<String> getExistingColumns(Connection conn, String table) throws SQLException {
        Set<String> set = new HashSet<>();
        DatabaseMetaData md = conn.getMetaData();
        try (ResultSet cols = md.getColumns(null, null, table, null)) {
            while (cols.next()) set.add(cols.getString("COLUMN_NAME"));
        }
        return set;
    }

    /** 회원 프로필 DTO */
    public static class MemberProfile {
        private static final String DEFAULT_PROFILE_IMG = "/img/Icon/profile.png";

        private String memberId;
        private String name;        // name_kr
        private String engName;     // name_en(성)
        private String engLastName; // en_name(이름)
        private String korName;     // name_kr
        private String email;
        private String phone;
        private String birthDate;   // birth_Date
        private String gender;      // Gender
        private String grade;       // Member_grade
        private String passportNo;  // passport

        private String passportImgUrl; // passport_img_url
        private String profileImgUrl;  // profile_img_url
        private String paymentImgUrl;  // payment_img_url

        public String getMemberId() { return memberId; }
        public void setMemberId(String memberId) { this.memberId = memberId; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getEngName() { return engName; }
        public void setEngName(String engName) { this.engName = engName; }
        public String getEngLastName() { return engLastName; }
        public void setEngLastName(String engLastName) { this.engLastName = engLastName; }
        public String getKorName() { return korName; }
        public void setKorName(String korName) { this.korName = korName; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }
        public String getBirthDate() { return birthDate; }
        public void setBirthDate(String birthDate) { this.birthDate = birthDate; }
        public String getGender() { return gender; }
        public void setGender(String gender) { this.gender = gender; }
        public String getGrade() { return grade; }
        public void setGrade(String grade) { this.grade = grade; }
        public String getPassportNo() { return passportNo; }
        public void setPassportNo(String passportNo) { this.passportNo = passportNo; }

        public String getPassportImgUrl() { return passportImgUrl; }
        public void setPassportImgUrl(String passportImgUrl) { this.passportImgUrl = passportImgUrl; }
        public String getProfileImgUrl() { return profileImgUrl; }
        public void setProfileImgUrl(String profileImgUrl) { this.profileImgUrl = profileImgUrl; }
        public String getPaymentImgUrl() { return paymentImgUrl; }
        public void setPaymentImgUrl(String paymentImgUrl) { this.paymentImgUrl = paymentImgUrl; }

        public String getProfileImageUrlOrDefault() {
            if (profileImgUrl != null && !profileImgUrl.isBlank()) return profileImgUrl;
            return DEFAULT_PROFILE_IMG;
        }
        public String getFullEngName() {
            if (engName != null && engLastName != null) return engName + " " + engLastName;
            if (engName != null) return engName;
            if (engLastName != null) return engLastName;
            return "";
        }
    }

    /** 이메일 중복 여부 */
    public boolean existsEmail(String email) {
        String sql = "SELECT COUNT(*) FROM javaDB WHERE email = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("[existsEmail] SQL 오류: " + e);
            return false;
        }
    }

    /** 회원가입 (기본 등급: 일반회원) */
    public boolean registerMember(String name, String passportFirstName, String passportLastName,
                                  String email, String phone, String birthdate,
                                  String gender, String password) {
        String sql = "INSERT INTO javaDB " +
                "(name_kr, name_en, en_name, email, phone, birth_Date, Gender, Password, Member_grade) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, passportFirstName);
            ps.setString(3, passportLastName);
            ps.setString(4, email);
            ps.setString(5, phone);
            ps.setString(6, birthdate);
            ps.setString(7, gender);
            ps.setString(8, password);          // 운영 시 해시 필요
            ps.setString(9, "일반회원");
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[registerMember] SQL 오류: " + e);
            return false;
        }
    }

    /** 로그인 인증 (평문 비교 → 운영 시 해시 비교로 변경) */
    public boolean authenticate(String email, String password) {
        String sql = "SELECT Password FROM javaDB WHERE email = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String dbPassword = rs.getString("Password");
                    return password.equals(dbPassword);
                }
                return false;
            }
        } catch (SQLException e) {
            System.err.println("[authenticate] SQL 오류: " + e);
            return false;
        }
    }

    /** 회원 정보 조회 */
    public MemberProfile getMemberByEmail(String email) {
        String sql = "SELECT * FROM javaDB WHERE email = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    MemberProfile p = new MemberProfile();
                    if (hasColumn(rs, "member_id"))     p.setMemberId(rs.getString("member_id"));
                    if (hasColumn(rs, "name_kr"))       { p.setName(rs.getString("name_kr")); p.setKorName(rs.getString("name_kr")); }
                    if (hasColumn(rs, "name_en"))       p.setEngName(rs.getString("name_en"));
                    if (hasColumn(rs, "en_name"))       p.setEngLastName(rs.getString("en_name"));
                    if (hasColumn(rs, "email"))         p.setEmail(rs.getString("email"));
                    if (hasColumn(rs, "phone"))         p.setPhone(rs.getString("phone"));
                    if (hasColumn(rs, "birth_Date"))    p.setBirthDate(rs.getString("birth_Date"));
                    if (hasColumn(rs, "Gender"))        p.setGender(rs.getString("Gender"));
                    if (hasColumn(rs, "Member_grade"))  p.setGrade(rs.getString("Member_grade"));
                    if (hasColumn(rs, "passport"))      p.setPassportNo(rs.getString("passport"));
                    if (hasColumn(rs, "passport_img_url")) p.setPassportImgUrl(rs.getString("passport_img_url"));
                    if (hasColumn(rs, "payment_img_url"))  p.setPaymentImgUrl(rs.getString("payment_img_url"));
                    if (hasColumn(rs, "profile_img_url"))  p.setProfileImgUrl(rs.getString("profile_img_url"));
                    return p;
                }
            }
        } catch (SQLException e) {
            System.err.println("[getMemberByEmail] SQL 오류: " + e);
        }
        return null;
    }

    /** 정회원 신청 (단순 버전: 등급/여권번호만) */
    public boolean registerRegularMember(String email, String passportNo,
                                         MultipartFile passportImg, MultipartFile dummy1, MultipartFile dummy2) {
        String sql = "UPDATE javaDB SET Member_grade = ?, passport = ? WHERE email = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "신청중");
            ps.setString(2, passportNo);
            ps.setString(3, email);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[registerRegularMember] SQL 오류: " + e);
            return false;
        }
    }

    /** 정회원 신청 (이미지 URL 포함 – 존재하는 컬럼만 업데이트) */
    public boolean registerRegularMemberWithAllImages(String email,
                                                      String passportNo,
                                                      String passportImgUrl,
                                                      String profileImgUrl,
                                                      String paymentImgUrl) {
        try (Connection conn = getConnection()) {
            Set<String> cols = getExistingColumns(conn, "javaDB");
            StringBuilder sb = new StringBuilder("UPDATE javaDB SET Member_grade = ?, passport = ?");
            if (cols.contains("passport_img_url")) sb.append(", passport_img_url = ?");
            if (cols.contains("profile_img_url"))  sb.append(", profile_img_url = ?");
            if (cols.contains("payment_img_url"))  sb.append(", payment_img_url = ?");
            sb.append(" WHERE email = ?");

            try (PreparedStatement ps = conn.prepareStatement(sb.toString())) {
                int idx = 1;
                ps.setString(idx++, "신청중");
                ps.setString(idx++, passportNo);
                if (cols.contains("passport_img_url")) ps.setString(idx++, passportImgUrl);
                if (cols.contains("profile_img_url"))  ps.setString(idx++, profileImgUrl);
                if (cols.contains("payment_img_url"))  ps.setString(idx++, paymentImgUrl);
                ps.setString(idx, email);
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("[registerRegularMemberWithAllImages] SQL 오류: " + e);
            return false;
        }
    }

    /** 정회원 승인 여부 확인 */
    public boolean approveMember(String email) {
        String sql = "SELECT Member_grade FROM javaDB WHERE email = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return "정회원".equals(rs.getString("Member_grade"));
                return false;
            }
        } catch (SQLException e) {
            System.err.println("[approveMember] SQL 오류: " + e);
            return false;
        }
    }
}