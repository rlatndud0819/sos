package main.web;

import logging.MemberEventLogger;
import org.mindrot.jbcrypt.BCrypt;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class change_my_info {

    @Resource(name = "fmkDatabase")
    private FMK_DB fmkDatabase;

    @Autowired
    private MemberEventLogger eventLogger;

    private String user(HttpServletRequest r){
        HttpSession s = r.getSession(false);
        return s != null ? (String)s.getAttribute("userEmail") : null;
    }

    @GetMapping("/change_my_info.do")
    public String viewChangeForm(HttpServletRequest req, Model model){
        String email = user(req);
        if(email == null) return "redirect:/login.do";
        FMK_DB.MemberProfile p = fmkDatabase.getMemberByEmail(email);
        if (p != null) model.addAttribute("memberVo", p);
        return "member/change_my_info";
    }

    @PostMapping("/change_my_info_update.do")
    public String updateProfile(HttpServletRequest request, RedirectAttributes ra){
        String email = user(request);
        if(email == null){
            ra.addFlashAttribute("error","로그인이 필요합니다.");
            return "redirect:/login.do";
        }

        try{
            // 1) 기본 텍스트
            String name      = request.getParameter("name");
            String phone     = request.getParameter("phone");
            String birthdate = request.getParameter("birthdate");
            String gender    = request.getParameter("gender");
            boolean textOk   = fmkDatabase.updateMemberBasics(email, name, phone, birthdate, gender);

            // 2) 비밀번호 변경(선택)
            String newPw = request.getParameter("newPassword");
            String confirmPw = request.getParameter("confirmPassword");
            if (newPw != null && !newPw.trim().isEmpty()) {
                if (!newPw.equals(confirmPw)) {
                    ra.addFlashAttribute("error", "비밀번호 확인이 일치하지 않습니다.");
                    return "redirect:/change_my_info.do";
                }
                String hashed = BCrypt.hashpw(newPw, BCrypt.gensalt(10));
                boolean pwOk = fmkDatabase.updatePasswordHash(email, hashed);
                if (pwOk) eventLogger.passwordChanged(email);
            }

            // 3) 이미지 URL 업데이트
            // 입력 우선순위: 업로드된 파일 → 폼의 URL 텍스트
            String passportImgUrlParam = request.getParameter("passportImgUrl");
            String paymentImgUrlParam  = request.getParameter("paymentImgUrl");
            String profileUrlParam     = request.getParameter("profileUrl");

            if (request instanceof MultipartHttpServletRequest) {
                MultipartHttpServletRequest mr = (MultipartHttpServletRequest) request;

                MultipartFile passportImg = mr.getFile("passportImg");
                if (passportImg != null && !passportImg.isEmpty()){
                    UploadUtil.Saved saved = UploadUtil.saveAndReturnUrl(passportImg, "passport_" + email);
                    if (saved != null) passportImgUrlParam = saved.publicUrl;
                }

                MultipartFile feeImg = mr.getFile("feeImg");
                if (feeImg != null && !feeImg.isEmpty()){
                    UploadUtil.Saved saved = UploadUtil.saveAndReturnUrl(feeImg, "payment_" + email);
                    if (saved != null) paymentImgUrlParam = saved.publicUrl;
                }

                MultipartFile profileImg = mr.getFile("profileImg");
                if (profileImg != null && !profileImg.isEmpty()){
                    UploadUtil.Saved saved = UploadUtil.saveAndReturnUrl(profileImg, "profile_" + email);
                    if (saved != null) profileUrlParam = saved.publicUrl;
                }
            }

            if (passportImgUrlParam != null && !passportImgUrlParam.trim().isEmpty()){
                fmkDatabase.updatePassportImgUrl(email, passportImgUrlParam.trim());
            }
            if (paymentImgUrlParam != null && !paymentImgUrlParam.trim().isEmpty()){
                fmkDatabase.updatePaymentImgUrl(email, paymentImgUrlParam.trim());
            }
            if (profileUrlParam != null && !profileUrlParam.trim().isEmpty()){
                fmkDatabase.updateProfileImgUrl(email, profileUrlParam.trim());
            }

            if (textOk) eventLogger.profileChanged(email);
            ra.addFlashAttribute("successMessage","회원정보가 수정되었습니다.");
            return "redirect:/See_more.do";

        }catch(Exception e){
            e.printStackTrace();
            ra.addFlashAttribute("error","수정 중 오류가 발생했습니다.");
            return "redirect:/change_my_info.do";
        }
    }
}