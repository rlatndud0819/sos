// src/main/java/main/web/memberController.java
package main.web;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import logging.MemberEventLogger;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.file.*;
import java.util.Arrays;
import java.util.List;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

@Controller
public class memberController {

    @Resource(name = "fmkDatabase")
    private FMK_DB fmkDatabase;

    @Resource
    private ServletContext servletContext;

    @Autowired
    private MemberEventLogger eventLogger;

    // -----------------------------
    // 공통 유틸
    // -----------------------------
    private static boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }

    /** 세션에서 로그인 이메일 반환 */
    private String user(HttpServletRequest r){
        HttpSession s = r.getSession(false);
        return s != null ? (String)s.getAttribute("userEmail") : null;
    }

    /** 서버 베이스 URL (http[s]://host[:port]/contextPath) */
    private String getServerBaseUrl(HttpServletRequest request) {
        String scheme = request.getScheme();
        String host = request.getServerName();
        int port = request.getServerPort();
        String ctx = request.getContextPath();
        boolean isDefaultPort = ("http".equals(scheme) && port == 80) || ("https".equals(scheme) && port == 443);
        return scheme + "://" + host + (isDefaultPort ? "" : (":" + port)) + ctx;
    }

    /** 이미지 확장자 화이트리스트 */
    private static String safeExt(String original) {
        String name = original == null ? "" : original;
        int dot = name.lastIndexOf('.');
        String ext = (dot >= 0 ? name.substring(dot + 1) : "").toLowerCase();
        if (ext.matches("^(jpg|jpeg|png|gif|webp)$")) return ext;
        throw new IllegalArgumentException("허용되지 않는 이미지 확장자");
    }

    /**
     * 업로드 저장
     * - 실제 파일: XML의 /uploads/** 매핑 대상 경로 중 하나에 저장
     * - DB: 절대 URL (예: http://localhost:8080/dpgb/uploads/passport/xxx.png)
     */
    private String saveImageToLocal(HttpServletRequest request,
                                    MultipartFile file, String userEmail, String imageType) throws Exception {
        if (file == null || file.isEmpty()) return null;

        String sub = (imageType == null || imageType.trim().isEmpty()) ? "misc" : imageType.trim();

        // XML과 동일한 후보 순서
        String home = System.getProperty("user.home");
        Path p1 = Paths.get(home, "uploads"); // file:${user.home}/uploads/
        Path p2 = Paths.get("/root/tomcat/webapps/uploads"); // 운영
        String realRes = servletContext.getRealPath("/resources/uploads"); // 배포 폴더 내부
        Path p3 = (realRes != null) ? Paths.get(realRes) : null;

        List<Path> roots = (p3 == null)
                ? Arrays.asList(p1, p2)
                : Arrays.asList(p1, p2, p3);

        Path chosenRoot = null;
        for (Path r : roots) {
            try {
                Files.createDirectories(r);
                Path test = r.resolve("._writable_check");
                Files.createDirectories(test);
                chosenRoot = r;
                break;
            } catch (Exception ignore) {}
        }
        if (chosenRoot == null) {
            chosenRoot = p1;
            Files.createDirectories(chosenRoot);
        }

        Path dir = chosenRoot.resolve(sub).normalize();
        Files.createDirectories(dir);

        String ext = safeExt(file.getOriginalFilename());
        String base = (userEmail == null ? "guest" : userEmail).replaceAll("[^a-zA-Z0-9._-]", "_");
        String fileName = base + "_" + System.currentTimeMillis() + "." + ext;

        Path target = dir.resolve(fileName).normalize();
        if (!target.startsWith(dir)) throw new SecurityException("경로 역탈출 감지");

        try (InputStream in = file.getInputStream()) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
        }

        String publicPath = "/uploads/" + sub + "/" + fileName;
        return getServerBaseUrl(request) + publicPath;
    }

    /** 프로필 이미지 표시용 URL 선택 (절대/상대 모두 안전) */
    private String resolveProfileImgSrc(FMK_DB.MemberProfile p, HttpServletRequest request) {
        String v = null;
        if (p != null) {
            if (!isBlank(p.getProfileImgUrl()))  v = p.getProfileImgUrl();
            else if (!isBlank(p.getPassportImgUrl())) v = p.getPassportImgUrl();
        }
        if (isBlank(v)) return request.getContextPath() + "/img/Icon/profile.png";
        if (v.startsWith("http://") || v.startsWith("https://")) return v; // DB에 절대 URL이면 그대로
        return request.getContextPath() + (v.startsWith("/") ? v : ("/" + v));
    }

    // -----------------------------
    // 공통 모델
    // -----------------------------
    @ModelAttribute("profile")
    public FMK_DB.MemberProfile preloadProfile(HttpServletRequest request){
        String email = user(request);
        if (email == null) return null;
        FMK_DB.MemberProfile p = fmkDatabase.getMemberByEmail(email);
        if (p != null) {
            if (p.getPassportImgUrl() == null) p.setPassportImgUrl("");
            if (p.getPaymentImgUrl() == null)  p.setPaymentImgUrl("");
            if (p.getProfileImgUrl() == null)  p.setProfileImgUrl("");
        }
        return p;
    }

    // -----------------------------
    // 화면 이동
    // -----------------------------
    @GetMapping("/signup.do") public String signup(){ return "member/signup"; }
    @GetMapping("/signAccess.do") public String signAccess(){ return "member/signAccess"; }
    @GetMapping("/login.do") public String login(){ return "member/login"; }

    @GetMapping("/Benefit.do")
    public String benefit(HttpServletRequest request, Model model){
        String email = user(request);
        if(email == null) return "redirect:/login.do";
        FMK_DB.MemberProfile memberVo = fmkDatabase.getMemberByEmail(email);
        if (memberVo != null) {
            model.addAttribute("memberVo", memberVo);
            model.addAttribute("profileImgSrc", resolveProfileImgSrc(memberVo, request));
        }
        return "member/Benefit";
    }

    @GetMapping("/See_more.do")
    public String See_more(HttpServletRequest request, Model model){
        String email = user(request);
        if(email == null) return "redirect:/login.do";
        FMK_DB.MemberProfile memberVo = fmkDatabase.getMemberByEmail(email);
        if (memberVo != null) {
            model.addAttribute("memberVo", memberVo);
            model.addAttribute("profileImgSrc", resolveProfileImgSrc(memberVo, request));
        }
        return "member/See_more";
    }

    // -----------------------------
    // 테스트/QR
    // -----------------------------
    @GetMapping("/testJDBC.do")
    @ResponseBody
    public String testJDBC() {
        try {
            Class.forName("com.filemaker.jdbc.Driver");
            java.sql.Connection conn = java.sql.DriverManager.getConnection(
                "jdbc:filemaker://xcd006.cafe24.com:2399/KSY_MypageDB",
                "admin", "2211"
            );
            conn.close();
            return "JDBC 연결 테스트 성공";
        } catch (ClassNotFoundException e) {
            return "드라이버 로드 실패: " + e.getMessage();
        } catch (java.sql.SQLException e) {
            return "DB 연결 실패: " + e.getMessage();
        }
    }

    @GetMapping("/generateQRCode.do")
    public void generateQRCode(HttpServletResponse response, HttpServletRequest request) {
        try {
            HttpSession session = request.getSession(false);
            if (session == null || session.getAttribute("userEmail") == null) {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                return;
            }
            response.setContentType("image/png");
            response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            response.setHeader("Pragma", "no-cache");
            response.setHeader("Expires", "0");

            String userToken = (String) session.getAttribute("userEmail");
            if (userToken == null) userToken = "guest";
            String qrUrl = getServerBaseUrl(request) + "/qrAuthSuccess.do?token=" + userToken;

            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(qrUrl, BarcodeFormat.QR_CODE, 300, 300);

            BufferedImage img = new BufferedImage(300, 300, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = img.createGraphics();
            g.setColor(Color.WHITE); g.fillRect(0, 0, 300, 300);
            g.setColor(Color.BLACK);
            for (int x = 0; x < 300; x++) {
                for (int y = 0; y < 300; y++) {
                    if (bitMatrix.get(x, y)) g.fillRect(x, y, 1, 1);
                }
            }
            g.dispose();
            ImageIO.write(img, "png", response.getOutputStream());
            response.getOutputStream().flush();
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/qrAuth.do")
    public String qrAuth(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        String contextPath = request.getContextPath();
        if (session != null && session.getAttribute("userEmail") != null) {
            return "redirect:" + contextPath + "/qrAuthSuccess.do";
        } else {
            return "redirect:" + contextPath + "/login.do?message=qr_login_required";
        }
    }

    @GetMapping("/qrAuthSuccess.do")
    public String qrAuthSuccess(HttpServletRequest request, Model model,
                               @RequestParam(value = "token", required = false) String token) {
        HttpSession session = request.getSession();
        String email = user(request);

        if (token != null && !"guest".equals(token) && email == null) {
            session.setAttribute("userEmail", token);
            email = token;
        }
        if (email == null) return "redirect:/login.do?message=qr_session_expired";

        FMK_DB.MemberProfile memberVo = fmkDatabase.getMemberByEmail(email);
        if (memberVo != null) {
            model.addAttribute("memberVo", memberVo);
            model.addAttribute("qrAuthSuccess", true);
            model.addAttribute("successMessage", "QR 코드 스캔이 성공적으로 완료되었습니다");
            model.addAttribute("profileImgSrc", resolveProfileImgSrc(memberVo, request));
            return "member/qr_auth_success";
        }
        return "redirect:/login.do";
    }

    // -----------------------------
    // 정회원 신청 (업로드)
    // -----------------------------
    @PostMapping("/member/upgrade.do")
    public String upgrade(HttpServletRequest request, RedirectAttributes ra) {
        try {
            if (!(request instanceof MultipartHttpServletRequest)) {
                ra.addFlashAttribute("error", "파일 업로드 설정에 문제가 있습니다");
                return "redirect:/regular_member.do";
            }
            MultipartHttpServletRequest mr = (MultipartHttpServletRequest) request;

            String email = user(request);
            if (email == null) {
                ra.addFlashAttribute("error", "로그인이 필요합니다");
                return "redirect:/login.do";
            }

            String passportNo = mr.getParameter("passportNo");
            MultipartFile passportImg = mr.getFile("passportImg");
            MultipartFile feeImg = mr.getFile("feeImg");
            MultipartFile profileImg = mr.getFile("profileImg");

            if (isBlank(passportNo)) {
                ra.addFlashAttribute("error", "여권번호를 입력해주세요");
                return "redirect:/regular_member.do";
            }
            if (passportImg == null || passportImg.isEmpty()) {
                ra.addFlashAttribute("error", "여권 이미지를 업로드해주세요");
                return "redirect:/regular_member.do";
            }

            String passportImgUrl = saveImageToLocal(request, passportImg, email, "passport");
            String paymentImgUrl  = (feeImg != null && !feeImg.isEmpty())
                    ? saveImageToLocal(request, feeImg, email, "payment") : null;
            String profileImgUrl  = (profileImg != null && !profileImg.isEmpty())
                    ? saveImageToLocal(request, profileImg, email, "profile") : null;

            boolean ok = fmkDatabase.registerRegularMemberWithAllImages(
                email, passportNo, passportImgUrl, profileImgUrl, paymentImgUrl
            );
            if (ok) {
                ra.addFlashAttribute("successMessage","정회원 신청이 완료되었습니다");
                return "redirect:/late_regular_member.do";
            } else {
                ra.addFlashAttribute("error", "처리 중 오류가 발생했습니다");
                return "redirect:/regular_member.do";
            }
        } catch (Exception e) {
            ra.addFlashAttribute("error", "시스템 오류가 발생했습니다");
            return "redirect:/regular_member.do";
        }
    }

    // -----------------------------
    // 상태 확인
    // -----------------------------
    @PostMapping("/checkApprovalStatus.do")
    public String checkApprovalStatus(HttpServletRequest r, RedirectAttributes ra) {
        String email = user(r);
        if(email == null) {
            ra.addFlashAttribute("errorMessage", "로그인이 필요합니다");
            return "redirect:/login.do";
        }
        FMK_DB.MemberProfile profile = fmkDatabase.getMemberByEmail(email);
        if (profile != null) {
            String currentGrade = profile.getGrade();
            if ("정회원".equals(currentGrade)) {
                ra.addFlashAttribute("successMessage","정회원 승인이 완료되었습니다");
                return "redirect:/success_regular_member.do";
            } else if ("신청중".equals(currentGrade)) {
                ra.addFlashAttribute("statusMessage","현재 상태: 신청중");
                return "redirect:/late_regular_member.do";
            } else {
                ra.addFlashAttribute("statusMessage","현재 상태: " + currentGrade);
                return "redirect:/late_regular_member.do";
            }
        } else {
            ra.addFlashAttribute("errorMessage","회원 정보를 조회할 수 없습니다");
            return "redirect:/late_regular_member.do";
        }
    }

    // -----------------------------
    // 회원가입/로그인/메인
    // -----------------------------
    @PostMapping("/join.do")
    public String join(MemberVO vo, Model m){
        String email = vo.getEmail().trim().toLowerCase();
        if(fmkDatabase.existsEmail(email)){
            m.addAttribute("dupEmailMsg","이미 등록된 이메일입니다");
            m.addAttribute("prefill_email",email);
            m.addAttribute("prefill_name", vo.getName());
            m.addAttribute("prefill_firstName", vo.getPassportFirstName());
            m.addAttribute("prefill_lastName", vo.getPassportLastName());
            m.addAttribute("prefill_phone", vo.getPhone());
            m.addAttribute("prefill_birthdate", vo.getBirthdate());
            m.addAttribute("prefill_gender", vo.getGender());
            return "member/signup";
        }

        boolean ok = fmkDatabase.registerMember(
                vo.getName(), vo.getPassportFirstName(), vo.getPassportLastName(),
                email, vo.getPhone(), vo.getBirthdate(), vo.getGender(), vo.getPassword());

        if(ok){
            eventLogger.signup(email);
            m.addAttribute("memberVo",vo);
            return "member/success";
        }
        m.addAttribute("error","가입 실패");
        return "member/signup";
    }

    @PostMapping("/login.do")
    public String doLogin(HttpServletRequest req, Model m){
        String email = req.getParameter("email").trim().toLowerCase();
        String pw = req.getParameter("password");
        if(fmkDatabase.authenticate(email,pw)){
            req.getSession(true).setAttribute("userEmail",email);
            eventLogger.login(email);
            return "redirect:/main.do";
        }
        m.addAttribute("loginError","로그인 실패");
        return "member/login";
    }

    @GetMapping("/regular_member.do")
    public String regularMember(HttpServletRequest r, Model m){
        String email = user(r);
        if(email == null) return "redirect:/login.do";
        m.addAttribute("memberVo", fmkDatabase.getMemberByEmail(email));
        return "member/regular_member";
    }

    @GetMapping("/late_regular_member.do")
    public String late(HttpServletRequest r, Model m){
        String email = user(r);
        if(email == null) return "redirect:/login.do";
        m.addAttribute("memberVo", fmkDatabase.getMemberByEmail(email));
        return "member/late_regular_member";
    }

    @GetMapping("/success_regular_member.do")
    public String success(HttpServletRequest r, Model m){
        String email = user(r);
        if(email == null) return "redirect:/login.do";
        m.addAttribute("memberVo", fmkDatabase.getMemberByEmail(email));
        return "member/success_regular_member";
    }

    @GetMapping("/main.do")
    public String main(HttpServletRequest request, Model model){
        String email = user(request);
        if(email == null) return "redirect:/login.do";
        FMK_DB.MemberProfile memberVo = fmkDatabase.getMemberByEmail(email);
        if (memberVo != null) {
            model.addAttribute("memberVo", memberVo);
            model.addAttribute("profileImgSrc", resolveProfileImgSrc(memberVo, request));
            String qrAuth = request.getParameter("qrAuth");
            if ("success".equals(qrAuth)) {
                model.addAttribute("qrAuthSuccess", true);
                model.addAttribute("successMessage", "QR 인증이 성공적으로 완료되었습니다");
            }
            return "member/main";
        }
        return "redirect:/login.do";
    }

    @GetMapping(value="/api/email-exists.do", produces="text/plain;charset=UTF-8")
    @ResponseBody
    public String emailExists(@RequestParam String email){
        return fmkDatabase.existsEmail(email.trim().toLowerCase()) ? "true" : "false";
    }

    @GetMapping("/logout.do")
    public String logout(HttpServletRequest r){
        HttpSession s = r.getSession(false);
        if(s != null){
            String email = (String) s.getAttribute("userEmail");
            if (email != null) eventLogger.logout(email);
            s.invalidate();
        }
        return "redirect:/login.do";
    }
}