package main.web;

import org.springframework.stereotype.Repository;

@Repository
public class MemberDAO {
    public MemberVO findByEmail(String email) {
        // 실제 구현이 없으면 null 반환으로 우선 컴파일 통과
        return null;
    }
}